# Коммиты и заливка на GitHub

Проект намеренно не инициализирует git, это делается вручную. Ниже готовый план осмысленных коммитов по этапам и короткая инструкция по публикации.

## План коммитов по этапам

Можно закоммитить всё сразу, но для аккуратной истории лучше разбить по этапам.

```bash
git init
git add .gitignore LICENSE pyproject.toml requirements.txt config/
git commit -m "chore: инициализация проекта, конфиг, зависимости и лицензия"

git add src/config.py src/__init__.py src/generator/
git commit -m "feat(generator): синтетический генератор событий SaaS за 12 месяцев

Пользователи с атрибутами привлечения, поведенческие сегменты, затухающее
удержание, сессии, монетизация (free to paid, MRR, churn) и инъекция грязных
данных. Полностью детерминирован seed'ом."

git add src/pipeline/ sql/staging/ sql/marts/
git commit -m "feat(pipeline): ELT на DuckDB и dbt-style SQL-модели

Слои raw, staging, marts. Мини dbt-раннер с ref() и source(), топологической
сортировкой и материализацией витрин: dim_users, dim_dates, fct_events,
fct_sessions, agg_daily_activity, cohort_retention."

git add sql/tests/
git commit -m "test(dq): data-quality тесты (uniqueness, not null, ссылочная целостность)"

git add src/metrics/ METRICS.md
git commit -m "feat(metrics): слой продуктовых метрик и их определения

DAU, WAU, MAU, stickiness, retention по дням и когортам, churn, free to paid,
воронка активации, MRR и разбивки по сегментам. Определения в METRICS.md."

git add dashboard/ .streamlit/
git commit -m "feat(dashboard): многостраничный Streamlit-дашборд с фильтрами и темами

Обзор с North Star и KPI, рост и активность, retention с heatmap, воронка,
выручка и сегменты. Plotly, светлая и тёмная тема."

git add tests/ .pre-commit-config.yaml .github/
git commit -m "ci: pytest, ruff и black, pre-commit и GitHub Actions"

git add notebooks/ docs/ Makefile README.md
git commit -m "docs: ноутбук с разбором, README с архитектурой и скриншотами, Makefile"
```

## Публикация на GitHub

Вариант A, через GitHub CLI, быстрый.

```bash
gh repo create product-analytics-platform --public --source=. --remote=origin --push
```

Вариант B, вручную. Сначала создайте на GitHub пустой репозиторий без README и лицензии, они уже есть в проекте. Имя product-analytics-platform, затем Create. После этого свяжите локальный репозиторий с удалённым и запушьте.

```bash
git branch -M main
git remote add origin https://github.com/<ваш-логин>/product-analytics-platform.git
git push -u origin main
```

## Описание репозитория

Для поля About подойдёт такой текст. Продуктовая аналитическая платформа, мини Amplitude. Генерация синтетических событий, обработка в DuckDB через dbt-style модели, слой продуктовых метрик и интерактивный дашборд на Streamlit. Стек: Python, DuckDB, SQL, Streamlit, Plotly, pytest, CI.

Topics можно поставить такие: product-analytics, data-engineering, duckdb, streamlit, elt, dbt, python, sql, analytics, dashboard, portfolio.

После пуша стоит заглянуть во вкладку Actions и убедиться, что CI прошёл, то есть линтеры и тесты зелёные. Папка data в репозиторий не попадает, данные генерируются командой make all на свежем клоне.
